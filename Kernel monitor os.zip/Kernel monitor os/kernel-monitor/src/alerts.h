#ifndef ALERTS_H
#define ALERTS_H

#include "process.h"

#define ALERT_THRESHOLD_CPU    80.0
#define ALERT_THRESHOLD_MEM    80.0
#define ALERT_CONSECUTIVE      3

/* Update alert states for all processes */
void alerts_update(process_list_t *list);

/* Get alert string for CPU */
const char *alert_cpu_string(process_info_t *proc);

/* Get alert string for Memory */
const char *alert_mem_string(process_info_t *proc);

#endif /* ALERTS_H */
