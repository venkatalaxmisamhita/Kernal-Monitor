#ifndef SYSCALL_MONITOR_H
#define SYSCALL_MONITOR_H

#include <sys/types.h>

#define MAX_SYSCALLS 64
#define MAX_RECENT_SYSCALLS 10
#define MAX_SYSCALL_NAME 64

typedef struct {
    char name[MAX_SYSCALL_NAME];
    int count;
} syscall_entry_t;

typedef struct {
    char timestamp[16];
    char name[MAX_SYSCALL_NAME];
} recent_syscall_t;

typedef struct {
    pid_t target_pid;
    syscall_entry_t entries[MAX_SYSCALLS];
    int entry_count;
    recent_syscall_t recent[MAX_RECENT_SYSCALLS];
    int recent_count;
    int available;          /* 1 if strace is available */
    pid_t strace_pid;       /* PID of running strace process */
    FILE *strace_fp;        /* pipe to strace */
} syscall_monitor_t;

/* Initialize syscall monitor */
void syscall_monitor_init(syscall_monitor_t *mon);

/* Start monitoring a specific PID */
void syscall_monitor_start(syscall_monitor_t *mon, pid_t pid);

/* Update syscall data (non-blocking read from strace pipe) */
void syscall_monitor_update(syscall_monitor_t *mon);

/* Stop monitoring */
void syscall_monitor_stop(syscall_monitor_t *mon);

/* Check if strace is available on the system */
int syscall_monitor_check_strace(void);

#endif /* SYSCALL_MONITOR_H */
