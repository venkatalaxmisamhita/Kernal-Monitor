#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <time.h>

#include "process.h"
#include "cpu.h"
#include "memory.h"
#include "io.h"
#include "syscall_monitor.h"
#include "alerts.h"
#include "display.h"

/* Global flag for clean shutdown */
static volatile sig_atomic_t running = 1;

static void signal_handler(int sig) {
    (void)sig;
    running = 0;
}

static void print_usage(const char *prog) {
    printf("Usage: %s [OPTIONS]\n\n", prog);
    printf("Options:\n");
    printf("  -p PID    Select a specific process for detailed monitoring\n");
    printf("  -h        Show this help message\n");
    printf("\nIf no PID is specified, the highest-CPU process is auto-selected.\n");
    printf("Press Ctrl+C to stop the monitor.\n");
}

int main(int argc, char *argv[]) {
    pid_t selected_pid = -1;

    /* Parse command-line arguments */
    int opt;
    while ((opt = getopt(argc, argv, "p:h")) != -1) {
        switch (opt) {
            case 'p':
                selected_pid = (pid_t)atoi(optarg);
                if (selected_pid <= 0) {
                    fprintf(stderr, "Error: Invalid PID '%s'\n", optarg);
                    return 1;
                }
                break;
            case 'h':
                print_usage(argv[0]);
                return 0;
            default:
                print_usage(argv[0]);
                return 1;
        }
    }

    /* Install signal handlers */
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = signal_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    sigaction(SIGINT, &sa, NULL);
    sigaction(SIGTERM, &sa, NULL);

    /* Initialize subsystems */
    process_list_t proc_list;
    system_cpu_t sys_cpu;
    system_memory_t sys_mem;
    syscall_monitor_t syscall_mon;

    process_list_init(&proc_list);
    cpu_init(&sys_cpu);
    memory_init(&sys_mem);
    syscall_monitor_init(&syscall_mon);

    /* Initial scan to populate previous values */
    process_scan_all(&proc_list);
    cpu_read_system(&sys_cpu);
    sleep(1);

    /* Main monitoring loop */
    while (running) {
        struct timespec start, end;
        clock_gettime(CLOCK_MONOTONIC, &start);

        /* 1. Scan all processes */
        process_scan_all(&proc_list);

        /* 2. Read system CPU and calculate */
        cpu_read_system(&sys_cpu);
        cpu_calculate_system(&sys_cpu);

        /* 3. Calculate per-process CPU */
        cpu_update_all(&proc_list, &sys_cpu);

        /* 4. Read system memory and calculate per-process memory */
        memory_read_system(&sys_mem);
        memory_update_all(&proc_list, &sys_mem);

        /* 5. Calculate I/O rates (dt = ~1 second) */
        io_update_all(&proc_list, 1.0);

        /* 6. Remove dead processes */
        process_remove_dead(&proc_list);

        /* 7. Sort by CPU usage */
        process_sort_by_cpu(&proc_list);

        /* 8. Determine selected process */
        process_info_t *selected = NULL;
        if (selected_pid > 0) {
            selected = process_find(&proc_list, selected_pid);
            if (!selected) {
                /* User-specified PID not found, fall back to highest CPU */
                if (proc_list.count > 0)
                    selected = &proc_list.procs[0];
            }
        } else {
            /* Auto-select highest CPU process */
            if (proc_list.count > 0)
                selected = &proc_list.procs[0];
        }

        /* 9. Update analysis for selected process */
        if (selected) {
            cpu_update_analysis(selected);
            memory_update_analysis(selected);
        }

        /* 10. Update syscall monitoring for selected process */
        if (selected) {
            syscall_monitor_start(&syscall_mon, selected->pid);
            syscall_monitor_update(&syscall_mon);
        }

        /* 11. Update alerts */
        alerts_update(&proc_list);

        /* 12. Render display */
        display_render(&proc_list, &sys_cpu, &sys_mem, selected, &syscall_mon);

        /* 13. Sleep for the remainder of 1 second */
        if (!running) break;

        clock_gettime(CLOCK_MONOTONIC, &end);
        double elapsed = (double)(end.tv_sec - start.tv_sec) +
                         (double)(end.tv_nsec - start.tv_nsec) / 1e9;

        if (elapsed < 1.0) {
            usleep((unsigned int)((1.0 - elapsed) * 1000000));
        }
    }

    /* Clean shutdown */
    printf("\n%sShutting down Kernel Monitor...%s\n", COLOR_YELLOW, COLOR_RESET);
    syscall_monitor_stop(&syscall_mon);
    printf("%sKernel Monitor terminated safely.%s\n", COLOR_GREEN, COLOR_RESET);

    return 0;
}
