#include "syscall_monitor.h"
#include "utils.h"
#include <signal.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <ctype.h>

void syscall_monitor_init(syscall_monitor_t *mon) {
    memset(mon, 0, sizeof(*mon));
    mon->target_pid = -1;
    mon->strace_pid = -1;
    mon->strace_fp = NULL;
    mon->available = syscall_monitor_check_strace();
}

int syscall_monitor_check_strace(void) {
    /* Check if strace is available */
    FILE *fp = popen("which strace 2>/dev/null", "r");
    if (!fp) return 0;

    char buf[MAX_PATH];
    int found = 0;
    if (fgets(buf, sizeof(buf), fp) != NULL) {
        if (strlen(buf) > 0 && buf[0] == '/')
            found = 1;
    }
    pclose(fp);
    return found;
}

void syscall_monitor_start(syscall_monitor_t *mon, pid_t pid) {
    if (!mon->available) return;
    if (pid <= 0) return;

    /* If already monitoring this PID, do nothing */
    if (mon->target_pid == pid && mon->strace_fp != NULL) return;

    /* Stop any existing monitoring */
    syscall_monitor_stop(mon);

    mon->target_pid = pid;
    mon->entry_count = 0;
    mon->recent_count = 0;

    /* Start strace with summary mode (-c) and time stamps (-T) */
    /* We use -c (summary) for counts, and a separate short trace for recent calls */
    char cmd[MAX_PATH * 2];

    /*
     * Run strace in counting mode for a brief period.
     * We use timeout to limit it to ~1 second per update cycle.
     * The -c flag produces a summary table of syscall counts.
     */
    snprintf(cmd, sizeof(cmd),
             "strace -p %d -c -S calls 2>&1",
             pid);

    mon->strace_fp = popen(cmd, "r");
    if (!mon->strace_fp) {
        mon->target_pid = -1;
        return;
    }

    /* Make the pipe non-blocking so update doesn't hang */
    int fd = fileno(mon->strace_fp);
    int flags = fcntl(fd, F_GETFL, 0);
    fcntl(fd, F_SETFL, flags | O_NONBLOCK);
}

/*
 * Parse a line from strace -c output.
 * Format: " % time     seconds  usecs/call     calls    errors syscall"
 * Example: "  2.70    0.000027           3         9           read"
 */
static int parse_strace_summary_line(const char *line, char *name, int *count) {
    /* Skip lines that are separators or headers */
    if (strstr(line, "------") || strstr(line, "% time") || strstr(line, "total"))
        return -1;

    /* Try to parse the fields */
    double pct;
    double seconds;
    int usecs;
    int calls;
    int errors;
    char syscall_name[MAX_SYSCALL_NAME];

    /* Try with errors field */
    int n = sscanf(line, " %lf %lf %d %d %d %63s",
                   &pct, &seconds, &usecs, &calls, &errors, syscall_name);
    if (n == 6) {
        strncpy(name, syscall_name, MAX_SYSCALL_NAME - 1);
        *count = calls;
        return 0;
    }

    /* Try without errors field */
    n = sscanf(line, " %lf %lf %d %d %63s",
               &pct, &seconds, &usecs, &calls, syscall_name);
    if (n == 5) {
        strncpy(name, syscall_name, MAX_SYSCALL_NAME - 1);
        *count = calls;
        return 0;
    }

    return -1;
}

void syscall_monitor_update(syscall_monitor_t *mon) {
    if (!mon->available || mon->target_pid <= 0) return;

    /*
     * Instead of maintaining a persistent strace (which blocks),
     * run a quick strace snapshot each update cycle.
     */

    /* Stop any existing strace */
    if (mon->strace_fp) {
        pclose(mon->strace_fp);
        mon->strace_fp = NULL;
    }

    /* Run strace -c for a very short burst using timeout */
    char cmd[MAX_PATH * 2];

    /* Use timeout to run strace -c for 0.5 seconds */
    snprintf(cmd, sizeof(cmd),
             "timeout 0.5 strace -p %d -c -S calls 2>&1",
             mon->target_pid);

    FILE *fp = popen(cmd, "r");
    if (!fp) return;

    char line[MAX_LINE];
    mon->entry_count = 0;

    while (fgets(line, sizeof(line), fp) != NULL) {
        if (mon->entry_count >= MAX_SYSCALLS) break;

        char name[MAX_SYSCALL_NAME] = {0};
        int count = 0;

        if (parse_strace_summary_line(line, name, &count) == 0) {
            strncpy(mon->entries[mon->entry_count].name, name, MAX_SYSCALL_NAME - 1);
            mon->entries[mon->entry_count].count = count;
            mon->entry_count++;
        }
    }
    pclose(fp);

    /* Now get recent syscalls with timestamps */
    snprintf(cmd, sizeof(cmd),
             "timeout 0.3 strace -p %d -tt -e trace=all 2>&1 | tail -n %d",
             mon->target_pid, MAX_RECENT_SYSCALLS);

    fp = popen(cmd, "r");
    if (!fp) return;

    mon->recent_count = 0;
    while (fgets(line, sizeof(line), fp) != NULL) {
        if (mon->recent_count >= MAX_RECENT_SYSCALLS) break;

        /* Parse timestamp and syscall name from strace output */
        /* Format: HH:MM:SS.ffffff syscall_name(...) = result */
        char timestamp[16] = {0};
        char syscall_name[MAX_SYSCALL_NAME] = {0};

        /* Extract timestamp (first 8 chars HH:MM:SS) */
        if (strlen(line) < 8) continue;
        if (!isdigit(line[0])) continue;

        strncpy(timestamp, line, 8);
        timestamp[8] = '\0';

        /* Find syscall name - it comes after the timestamp and spaces */
        char *p = line + 8;
        while (*p && (*p == '.' || isdigit(*p) || *p == ' ')) p++;

        /* Extract syscall name (up to '(') */
        int idx = 0;
        while (*p && *p != '(' && idx < MAX_SYSCALL_NAME - 3) {
            syscall_name[idx++] = *p++;
        }
        if (idx > 0) {
            syscall_name[idx] = '\0';
            /* Add () suffix */
            if (idx < MAX_SYSCALL_NAME - 3) {
                strcat(syscall_name, "()");
            }

            strncpy(mon->recent[mon->recent_count].timestamp, timestamp, 15);
            strncpy(mon->recent[mon->recent_count].name, syscall_name, MAX_SYSCALL_NAME - 1);
            mon->recent_count++;
        }
    }
    pclose(fp);
}

void syscall_monitor_stop(syscall_monitor_t *mon) {
    if (mon->strace_fp) {
        pclose(mon->strace_fp);
        mon->strace_fp = NULL;
    }

    if (mon->strace_pid > 0) {
        kill(mon->strace_pid, SIGTERM);
        waitpid(mon->strace_pid, NULL, WNOHANG);
        mon->strace_pid = -1;
    }

    mon->target_pid = -1;
    mon->entry_count = 0;
    mon->recent_count = 0;
}
