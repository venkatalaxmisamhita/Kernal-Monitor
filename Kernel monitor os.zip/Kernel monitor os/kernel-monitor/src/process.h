#ifndef PROCESS_H
#define PROCESS_H

#include "utils.h"
#include <dirent.h>
#include <sys/types.h>

#define MAX_PROCESSES 4096
#define STATE_RUNNING   'R'
#define STATE_SLEEPING  'S'
#define STATE_DISK_SLEEP 'D'
#define STATE_STOPPED   'T'
#define STATE_ZOMBIE    'Z'
#define STATE_IDLE      'I'

typedef struct {
    pid_t pid;
    pid_t ppid;
    char name[MAX_NAME];
    char state;
    char state_str[16];

    /* CPU fields */
    unsigned long utime;
    unsigned long stime;
    unsigned long prev_utime;
    unsigned long prev_stime;
    double cpu_percent;
    int cpu_core;           /* processor field from /proc/PID/stat */

    /* Memory fields */
    long vm_rss_kb;         /* VmRSS in KB */
    double mem_percent;
    double mem_mb;

    /* I/O fields */
    unsigned long long read_bytes;
    unsigned long long write_bytes;
    unsigned long long prev_read_bytes;
    unsigned long long prev_write_bytes;
    double read_rate;       /* MB/s */
    double write_rate;      /* MB/s */

    /* Thread count */
    int threads;

    /* Start time (clock ticks since boot) */
    unsigned long long starttime;
    unsigned long running_seconds;

    /* CPU analysis */
    double cpu_avg;
    double cpu_peak;
    double cpu_min;
    int cpu_sample_count;
    double cpu_sum;

    /* Memory analysis */
    double mem_avg;
    double mem_peak;
    double mem_min;
    int mem_sample_count;
    double mem_sum;

    /* Alert tracking */
    int cpu_high_count;     /* consecutive high CPU samples */
    int mem_high_count;     /* consecutive high memory samples */
    int cpu_alert;          /* 1 if alert active */
    int mem_alert;          /* 1 if alert active */

    /* Tracking */
    int active;             /* 1 if process found in current scan */
    int is_new;             /* 1 if just appeared */
} process_info_t;

typedef struct {
    process_info_t procs[MAX_PROCESSES];
    int count;
    int total_running;
    int total_sleeping;
    int total_stopped;
    int total_zombie;
} process_list_t;

/* Initialize process list */
void process_list_init(process_list_t *list);

/* Scan /proc for all processes. Updates existing entries, adds new ones. */
void process_scan_all(process_list_t *list);

/* Remove processes that are no longer active */
void process_remove_dead(process_list_t *list);

/* Find process by PID. Returns pointer or NULL. */
process_info_t *process_find(process_list_t *list, pid_t pid);

/* Get state string from state char */
const char *process_state_string(char state);

/* Count threads for a process via /proc/PID/task */
int process_count_threads(pid_t pid);

/* Sort process list by CPU usage descending */
void process_sort_by_cpu(process_list_t *list);

#endif /* PROCESS_H */
