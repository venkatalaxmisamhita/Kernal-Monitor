#ifndef UTILS_H
#define UTILS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <errno.h>

#define MAX_PATH 512
#define MAX_LINE 1024
#define MAX_NAME 256

/* Safely read the first line from a file. Returns 0 on success, -1 on failure. */
int read_file_line(const char *path, char *buf, size_t bufsz);

/* Read entire file content into buffer. Returns bytes read, or -1 on failure. */
int read_file_content(const char *path, char *buf, size_t bufsz);

/* Format seconds into HH:MM:SS string */
void format_time(unsigned long seconds, char *buf, size_t bufsz);

/* Safe string to long conversion. Returns 0 on success. */
int safe_atol(const char *str, long *out);

/* Get system uptime in seconds */
double get_uptime(void);

/* Get number of CPU cores */
int get_num_cpus(void);

/* Get current time as formatted string HH:MM:SS */
void get_time_string(char *buf, size_t bufsz);

#endif /* UTILS_H */
