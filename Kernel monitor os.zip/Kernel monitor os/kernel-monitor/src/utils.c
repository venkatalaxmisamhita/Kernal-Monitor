#include "utils.h"

int read_file_line(const char *path, char *buf, size_t bufsz) {
    FILE *fp = fopen(path, "r");
    if (!fp) return -1;
    if (!fgets(buf, (int)bufsz, fp)) {
        fclose(fp);
        return -1;
    }
    fclose(fp);
    /* Remove trailing newline */
    size_t len = strlen(buf);
    if (len > 0 && buf[len - 1] == '\n')
        buf[len - 1] = '\0';
    return 0;
}

int read_file_content(const char *path, char *buf, size_t bufsz) {
    FILE *fp = fopen(path, "r");
    if (!fp) return -1;
    size_t total = 0;
    size_t n;
    while ((n = fread(buf + total, 1, bufsz - total - 1, fp)) > 0) {
        total += n;
        if (total >= bufsz - 1) break;
    }
    buf[total] = '\0';
    fclose(fp);
    return (int)total;
}

void format_time(unsigned long seconds, char *buf, size_t bufsz) {
    unsigned long h = seconds / 3600;
    unsigned long m = (seconds % 3600) / 60;
    unsigned long s = seconds % 60;
    snprintf(buf, bufsz, "%02lu:%02lu:%02lu", h, m, s);
}

int safe_atol(const char *str, long *out) {
    if (!str || !out) return -1;
    char *end;
    errno = 0;
    long val = strtol(str, &end, 10);
    if (errno != 0 || end == str) return -1;
    *out = val;
    return 0;
}

double get_uptime(void) {
    char buf[128];
    if (read_file_line("/proc/uptime", buf, sizeof(buf)) != 0)
        return 0.0;
    double uptime = 0.0;
    sscanf(buf, "%lf", &uptime);
    return uptime;
}

int get_num_cpus(void) {
    int count = 0;
    FILE *fp = fopen("/proc/stat", "r");
    if (!fp) return 1;
    char line[MAX_LINE];
    while (fgets(line, sizeof(line), fp)) {
        if (strncmp(line, "cpu", 3) == 0 && line[3] >= '0' && line[3] <= '9')
            count++;
    }
    fclose(fp);
    return count > 0 ? count : 1;
}

void get_time_string(char *buf, size_t bufsz) {
    time_t now = time(NULL);
    struct tm *t = localtime(&now);
    snprintf(buf, bufsz, "%02d:%02d:%02d", t->tm_hour, t->tm_min, t->tm_sec);
}
