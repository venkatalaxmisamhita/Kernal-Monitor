# Kernel Monitor

A real-time Linux Process and Kernel Monitor written in C that continuously monitors **all running processes** on the system.

## Features

- **Multi-Process Monitoring** — Discovers and displays all running processes in real time
- **Real CPU Usage** — Per-process CPU% calculated from `/proc/stat` and `/proc/<PID>/stat` using jiffies deltas
- **Real Memory Usage** — RSS-based memory tracking from `/proc/<PID>/status` and `/proc/meminfo`
- **Process I/O Monitoring** — Read/write rates from `/proc/<PID>/io`
- **System Call Tracing** — Real syscall capture via `strace` for the selected process
- **Process Lifecycle** — Automatically detects new and terminated processes
- **CPU & Memory Analysis** — Tracks current, average, peak, minimum, trend, and status
- **Alert System** — Per-process alerts triggered after 3 consecutive samples above 80% threshold
- **Clean Terminal UI** — Color-coded ANSI output with formatted tables
- **Signal Handling** — Safe shutdown on Ctrl+C

## Requirements

- **Linux / Ubuntu** (requires `/proc` filesystem)
- **GCC** (C11 compatible)
- **strace** (for system call monitoring — optional but recommended)
- **make**

### Install dependencies (Ubuntu/Debian):

```bash
sudo apt update
sudo apt install build-essential strace
```

## Build

```bash
cd kernel-monitor
make
```

## Usage

```bash
# Monitor all processes (auto-selects highest CPU for detailed view)
./kernel_monitor

# Monitor with a specific process selected for detailed view
./kernel_monitor -p <PID>

# Show help
./kernel_monitor -h
```

### Running with system call monitoring

System call monitoring via `strace` may require elevated privileges:

```bash
# Run as root for full syscall access
sudo ./kernel_monitor

# Or for your own processes
./kernel_monitor -p $(pgrep -u $USER firefox)
```

## Project Structure

```
kernel-monitor/
├── src/
│   ├── main.c              — Entry point, signal handling, main loop
│   ├── process.c / .h      — /proc scanner, process list management
│   ├── cpu.c / .h           — Per-process & system CPU calculation
│   ├── memory.c / .h        — Per-process & system memory tracking
│   ├── io.c / .h            — Per-process I/O rate calculation
│   ├── syscall_monitor.c/.h — strace-based syscall capture
│   ├── display.c / .h       — Terminal rendering engine
│   ├── alerts.c / .h        — Threshold-based alert system
│   └── utils.c / .h         — File reading, time formatting helpers
├── tests/
│   └── test_cpu_stress.sh   — CPU stress test script
├── Makefile
└── README.md
```

## How It Works

### CPU Calculation
- Reads total system jiffies from `/proc/stat` (user, nice, system, idle, iowait, irq, softirq, steal)
- Reads per-process utime and stime from `/proc/<PID>/stat`
- Calculates: `CPU% = (Δprocess_jiffies / Δtotal_jiffies) × 100 × num_cpus`

### Memory Calculation
- Reads `VmRSS` from `/proc/<PID>/status` for resident memory
- Reads `MemTotal` and `MemAvailable` from `/proc/meminfo`
- Calculates: `MEM% = (VmRSS / MemTotal) × 100`

### I/O Rates
- Reads `read_bytes` and `write_bytes` from `/proc/<PID>/io`
- Calculates: `Rate = Δbytes / Δtime` (in MB/s)

### System Calls
- Uses `strace -p <PID> -c` for syscall count summaries
- Uses `strace -p <PID> -tt` for recent syscall timestamps
- Falls back gracefully if strace is unavailable

### Alerts
- Threshold: 80% for both CPU and memory
- Requires 3 consecutive samples above threshold before alert fires
- Per-process tracking, automatically cleaned up for terminated processes

## Controls

| Key     | Action                    |
|---------|---------------------------|
| Ctrl+C  | Stop the monitor safely   |

## Output Sections

1. **Header** — Process count, refresh rate
2. **Process Table** — Top 20 processes sorted by CPU usage
3. **Selected Process** — Detailed info for highest-CPU (or user-specified) process
4. **CPU Analysis** — Current, average, peak, minimum, trend, status
5. **Memory Analysis** — Current, average, peak, minimum, trend, status
6. **I/O Analysis** — Read/write rates and status
7. **System Call Activity** — Syscall counts and recent calls
8. **System Analysis** — Overall CPU, memory, health
9. **Alerts** — Active threshold alerts

## License

This project is for educational and system programming demonstration purposes.
