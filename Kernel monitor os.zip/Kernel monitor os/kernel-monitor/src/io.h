#ifndef IO_H
#define IO_H

#include "process.h"

/* Read I/O counters for a process from /proc/PID/io */
int io_read_process(process_info_t *proc);

/* Update I/O rates for all processes */
void io_update_all(process_list_t *list, double dt);

/* Get I/O status string */
const char *io_status_string(double read_rate, double write_rate);

#endif /* IO_H */
