#include "memory.h"

void memory_init(system_memory_t *mem) {
    memset(mem, 0, sizeof(*mem));
}

void memory_read_system(system_memory_t *mem) {
    char buf[MAX_LINE * 16];
    if (read_file_content("/proc/meminfo", buf, sizeof(buf)) <= 0)
        return;

    char *line;

    line = strstr(buf, "MemTotal:");
    if (line) sscanf(line, "MemTotal: %ld", &mem->total_kb);

    line = strstr(buf, "MemAvailable:");
    if (line) sscanf(line, "MemAvailable: %ld", &mem->available_kb);

    line = strstr(buf, "MemFree:");
    if (line) sscanf(line, "MemFree: %ld", &mem->free_kb);

    line = strstr(buf, "Buffers:");
    if (line) sscanf(line, "Buffers: %ld", &mem->buffers_kb);

    line = strstr(buf, "Cached:");
    if (line) sscanf(line, "Cached: %ld", &mem->cached_kb);

    if (mem->total_kb > 0) {
        long used = mem->total_kb - mem->available_kb;
        mem->used_percent = (double)used / (double)mem->total_kb * 100.0;
    }
}

void memory_update_all(process_list_t *list, system_memory_t *mem) {
    for (int i = 0; i < list->count; i++) {
        process_info_t *proc = &list->procs[i];
        if (!proc->active) continue;

        if (mem->total_kb > 0) {
            proc->mem_percent = (double)proc->vm_rss_kb / (double)mem->total_kb * 100.0;
        } else {
            proc->mem_percent = 0.0;
        }
        proc->mem_mb = (double)proc->vm_rss_kb / 1024.0;
    }
}

void memory_update_analysis(process_info_t *proc) {
    if (!proc) return;

    proc->mem_sample_count++;
    proc->mem_sum += proc->mem_percent;
    proc->mem_avg = proc->mem_sum / proc->mem_sample_count;

    if (proc->mem_percent > proc->mem_peak)
        proc->mem_peak = proc->mem_percent;
    if (proc->mem_percent < proc->mem_min)
        proc->mem_min = proc->mem_percent;
}

const char *memory_trend_string(process_info_t *proc) {
    if (!proc || proc->mem_sample_count < 2) return "Stable";

    double diff = proc->mem_percent - proc->mem_avg;
    if (diff > 2.0) return "Increasing";
    if (diff < -2.0) return "Decreasing";
    return "Stable";
}

const char *memory_status_string(double mem_percent) {
    if (mem_percent > 80.0) return "HIGH";
    if (mem_percent > 50.0) return "MODERATE";
    return "NORMAL";
}
