#include "process.h"
#include <ctype.h>
#include <signal.h>

void process_list_init(process_list_t *list) {
    memset(list, 0, sizeof(*list));
}

const char *process_state_string(char state) {
    switch (state) {
        case 'R': return "RUNNING";
        case 'S': return "SLEEPING";
        case 'D': return "DISK SLEEP";
        case 'T': return "STOPPED";
        case 't': return "TRACING";
        case 'Z': return "ZOMBIE";
        case 'X': return "DEAD";
        case 'I': return "IDLE";
        default:  return "UNKNOWN";
    }
}

/* Parse /proc/<pid>/stat to extract process info */
static int parse_proc_stat(pid_t pid, process_info_t *proc) {
    char path[MAX_PATH];
    char buf[MAX_LINE * 4];

    snprintf(path, sizeof(path), "/proc/%d/stat", pid);
    int bytes = read_file_content(path, buf, sizeof(buf));
    if (bytes <= 0) return -1;

    /* Find the process name between '(' and ')' — handles names with spaces */
    char *name_start = strchr(buf, '(');
    char *name_end = strrchr(buf, ')');
    if (!name_start || !name_end || name_end <= name_start) return -1;

    /* Extract name */
    size_t name_len = (size_t)(name_end - name_start - 1);
    if (name_len >= MAX_NAME) name_len = MAX_NAME - 1;
    strncpy(proc->name, name_start + 1, name_len);
    proc->name[name_len] = '\0';

    /* Parse fields after the closing ')' */
    char *p = name_end + 2; /* skip ') ' */
    if (p >= buf + bytes) return -1;

    char state;
    int ppid;
    unsigned long utime, stime;
    long num_threads;
    unsigned long long starttime;
    int processor;

    /*
     * Fields after (name):
     *  3: state
     *  4: ppid
     *  5-13: pgrp, session, tty_nr, tpgid, flags, minflt, cminflt, majflt, cmajflt
     * 14: utime
     * 15: stime
     * 16-19: cutime, cstime, priority, nice
     * 20: num_threads
     * 21: itrealvalue
     * 22: starttime
     * ...
     * 39: processor
     */
    int n = sscanf(p,
        "%c %d %*d %*d %*d %*d %*u %*u %*u %*u %*u "
        "%lu %lu %*d %*d %*d %*d "
        "%ld %*d %llu "
        "%*u %*u %*u %*u %*u %*u %*u %*u %*u %*u %*u %*u %*u "
        "%*d %*d %*u %*u %*d %d",
        &state, &ppid,
        &utime, &stime,
        &num_threads, &starttime,
        &processor);

    if (n < 6) {
        /* Try a minimal parse */
        n = sscanf(p, "%c %d %*d %*d %*d %*d %*u %*u %*u %*u %*u %lu %lu",
                   &state, &ppid, &utime, &stime);
        if (n < 4) return -1;
        num_threads = 1;
        starttime = 0;
        processor = 0;
    }

    proc->pid = pid;
    proc->ppid = ppid;
    proc->state = state;
    strncpy(proc->state_str, process_state_string(state), sizeof(proc->state_str) - 1);

    /* Save previous CPU times before updating */
    proc->prev_utime = proc->utime;
    proc->prev_stime = proc->stime;
    proc->utime = utime;
    proc->stime = stime;

    proc->threads = (int)num_threads;
    proc->starttime = starttime;
    proc->cpu_core = processor;

    /* Calculate running time */
    double uptime = get_uptime();
    long hz = sysconf(_SC_CLK_TCK);
    if (hz <= 0) hz = 100;
    double start_sec = (double)starttime / (double)hz;
    if (uptime > start_sec)
        proc->running_seconds = (unsigned long)(uptime - start_sec);
    else
        proc->running_seconds = 0;

    return 0;
}

/* Parse /proc/<pid>/status for memory info */
static int parse_proc_status(pid_t pid, process_info_t *proc) {
    char path[MAX_PATH];
    char buf[MAX_LINE * 8];

    snprintf(path, sizeof(path), "/proc/%d/status", pid);
    int bytes = read_file_content(path, buf, sizeof(buf));
    if (bytes <= 0) return -1;

    /* Find VmRSS line */
    char *line = strstr(buf, "VmRSS:");
    if (line) {
        long rss = 0;
        sscanf(line, "VmRSS: %ld", &rss);
        proc->vm_rss_kb = rss;
    } else {
        proc->vm_rss_kb = 0;
    }

    return 0;
}

/* Parse /proc/<pid>/io for I/O counters */
static int parse_proc_io(pid_t pid, process_info_t *proc) {
    char path[MAX_PATH];
    char buf[MAX_LINE * 4];

    snprintf(path, sizeof(path), "/proc/%d/io", pid);
    int bytes = read_file_content(path, buf, sizeof(buf));
    if (bytes <= 0) return -1;

    /* Save previous values */
    proc->prev_read_bytes = proc->read_bytes;
    proc->prev_write_bytes = proc->write_bytes;

    char *line;
    line = strstr(buf, "read_bytes:");
    if (line) {
        sscanf(line, "read_bytes: %llu", &proc->read_bytes);
    }
    line = strstr(buf, "\nwrite_bytes:");
    if (line) {
        sscanf(line + 1, "write_bytes: %llu", &proc->write_bytes);
    }

    return 0;
}

int process_count_threads(pid_t pid) {
    char path[MAX_PATH];
    snprintf(path, sizeof(path), "/proc/%d/task", pid);

    DIR *dir = opendir(path);
    if (!dir) return 1;

    int count = 0;
    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_name[0] != '.')
            count++;
    }
    closedir(dir);
    return count > 0 ? count : 1;
}

void process_scan_all(process_list_t *list) {
    /* Mark all current processes as inactive */
    for (int i = 0; i < list->count; i++) {
        list->procs[i].active = 0;
        list->procs[i].is_new = 0;
    }

    /* Reset state counts */
    list->total_running = 0;
    list->total_sleeping = 0;
    list->total_stopped = 0;
    list->total_zombie = 0;

    DIR *proc_dir = opendir("/proc");
    if (!proc_dir) return;

    struct dirent *entry;
    while ((entry = readdir(proc_dir)) != NULL) {
        /* Only process numeric directory names (PIDs) */
        if (!isdigit(entry->d_name[0]))
            continue;

        pid_t pid = (pid_t)atoi(entry->d_name);
        if (pid <= 0) continue;

        /* Skip kernel threads (PID 0 and 2 family) - optional, keep them */

        /* Find existing entry or create new */
        process_info_t *proc = process_find(list, pid);
        int is_new = 0;

        if (!proc) {
            /* New process */
            if (list->count >= MAX_PROCESSES) continue;
            proc = &list->procs[list->count];
            memset(proc, 0, sizeof(*proc));
            proc->cpu_min = 999.0;
            proc->mem_min = 999.0;
            list->count++;
            is_new = 1;
        }

        /* Parse /proc/<pid>/stat */
        if (parse_proc_stat(pid, proc) != 0) {
            /* Process may have exited between readdir and open */
            if (is_new) {
                list->count--;
            }
            continue;
        }

        /* Parse memory info */
        parse_proc_status(pid, proc);

        /* Parse I/O info (may fail for permission reasons) */
        parse_proc_io(pid, proc);

        /* Count threads */
        proc->threads = process_count_threads(pid);

        proc->active = 1;
        proc->is_new = is_new;

        /* Count states */
        switch (proc->state) {
            case 'R': list->total_running++; break;
            case 'S': case 'D': case 'I': list->total_sleeping++; break;
            case 'T': case 't': list->total_stopped++; break;
            case 'Z': list->total_zombie++; break;
        }
    }
    closedir(proc_dir);
}

void process_remove_dead(process_list_t *list) {
    int write_idx = 0;
    for (int i = 0; i < list->count; i++) {
        if (list->procs[i].active) {
            if (write_idx != i) {
                list->procs[write_idx] = list->procs[i];
            }
            write_idx++;
        }
    }
    list->count = write_idx;
}

process_info_t *process_find(process_list_t *list, pid_t pid) {
    for (int i = 0; i < list->count; i++) {
        if (list->procs[i].pid == pid)
            return &list->procs[i];
    }
    return NULL;
}

/* Comparison function for sorting by CPU descending */
static int cmp_cpu_desc(const void *a, const void *b) {
    const process_info_t *pa = (const process_info_t *)a;
    const process_info_t *pb = (const process_info_t *)b;
    if (pb->cpu_percent > pa->cpu_percent) return 1;
    if (pb->cpu_percent < pa->cpu_percent) return -1;
    return 0;
}

void process_sort_by_cpu(process_list_t *list) {
    if (list->count > 1) {
        qsort(list->procs, (size_t)list->count, sizeof(process_info_t), cmp_cpu_desc);
    }
}
