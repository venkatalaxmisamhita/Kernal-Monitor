#ifndef CPU_H
#define CPU_H

#include "process.h"

typedef struct {
    unsigned long long total_prev;
    unsigned long long idle_prev;
    unsigned long long total_cur;
    unsigned long long idle_cur;
    double overall_cpu_percent;
    int num_cpus;
} system_cpu_t;

/* Initialize system CPU tracking */
void cpu_init(system_cpu_t *sys);

/* Read system-wide CPU jiffies from /proc/stat */
void cpu_read_system(system_cpu_t *sys);

/* Calculate overall system CPU usage */
void cpu_calculate_system(system_cpu_t *sys);

/* Update CPU usage for all processes */
void cpu_update_all(process_list_t *list, system_cpu_t *sys);

/* Update CPU analysis for the selected process */
void cpu_update_analysis(process_info_t *proc);

/* Get CPU trend string */
const char *cpu_trend_string(process_info_t *proc);

/* Get CPU status string */
const char *cpu_status_string(double cpu_percent);

#endif /* CPU_H */
