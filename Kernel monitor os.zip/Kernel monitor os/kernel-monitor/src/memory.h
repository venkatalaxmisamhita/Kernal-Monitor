#ifndef MEMORY_H
#define MEMORY_H

#include "process.h"

typedef struct {
    long total_kb;
    long available_kb;
    long free_kb;
    long buffers_kb;
    long cached_kb;
    double used_percent;
} system_memory_t;

/* Initialize system memory info */
void memory_init(system_memory_t *mem);

/* Read system memory from /proc/meminfo */
void memory_read_system(system_memory_t *mem);

/* Update memory for all processes */
void memory_update_all(process_list_t *list, system_memory_t *mem);

/* Update memory analysis for the selected process */
void memory_update_analysis(process_info_t *proc);

/* Get memory trend string */
const char *memory_trend_string(process_info_t *proc);

/* Get memory status string */
const char *memory_status_string(double mem_percent);

#endif /* MEMORY_H */
