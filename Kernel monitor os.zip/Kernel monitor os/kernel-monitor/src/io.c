#include "io.h"

int io_read_process(process_info_t *proc) {
    char path[MAX_PATH];
    char buf[MAX_LINE * 4];

    snprintf(path, sizeof(path), "/proc/%d/io", proc->pid);
    int bytes = read_file_content(path, buf, sizeof(buf));
    if (bytes <= 0) return -1;

    /* Save previous */
    proc->prev_read_bytes = proc->read_bytes;
    proc->prev_write_bytes = proc->write_bytes;

    char *line;
    line = strstr(buf, "read_bytes:");
    if (line) sscanf(line, "read_bytes: %llu", &proc->read_bytes);

    line = strstr(buf, "\nwrite_bytes:");
    if (line) sscanf(line + 1, "write_bytes: %llu", &proc->write_bytes);

    return 0;
}

void io_update_all(process_list_t *list, double dt) {
    if (dt <= 0.0) dt = 1.0;

    for (int i = 0; i < list->count; i++) {
        process_info_t *proc = &list->procs[i];
        if (!proc->active) continue;

        /* Calculate rates in MB/s */
        if (proc->prev_read_bytes > 0 || proc->prev_write_bytes > 0) {
            unsigned long long read_delta = 0;
            unsigned long long write_delta = 0;

            if (proc->read_bytes >= proc->prev_read_bytes)
                read_delta = proc->read_bytes - proc->prev_read_bytes;
            if (proc->write_bytes >= proc->prev_write_bytes)
                write_delta = proc->write_bytes - proc->prev_write_bytes;

            proc->read_rate = (double)read_delta / (1024.0 * 1024.0) / dt;
            proc->write_rate = (double)write_delta / (1024.0 * 1024.0) / dt;
        } else {
            proc->read_rate = 0.0;
            proc->write_rate = 0.0;
        }
    }
}

const char *io_status_string(double read_rate, double write_rate) {
    double total = read_rate + write_rate;
    if (total > 100.0) return "HIGH";
    if (total > 50.0) return "MODERATE";
    return "NORMAL";
}
