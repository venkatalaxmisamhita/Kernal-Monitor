#ifndef DISPLAY_H
#define DISPLAY_H

#include "process.h"
#include "cpu.h"
#include "memory.h"
#include "syscall_monitor.h"

/* ANSI color codes */
#define COLOR_RESET   "\033[0m"
#define COLOR_RED     "\033[1;31m"
#define COLOR_GREEN   "\033[1;32m"
#define COLOR_YELLOW  "\033[1;33m"
#define COLOR_CYAN    "\033[1;36m"
#define COLOR_BOLD    "\033[1m"
#define COLOR_DIM     "\033[2m"

#define MAX_DISPLAY_PROCS 20   /* Max processes to show in table */

/* Clear terminal screen */
void display_clear(void);

/* Render the full monitor display */
void display_render(
    process_list_t *list,
    system_cpu_t *sys_cpu,
    system_memory_t *sys_mem,
    process_info_t *selected,
    syscall_monitor_t *syscall_mon
);

/* Print a separator line */
void display_separator(void);

/* Print a section header */
void display_section(const char *title);

#endif /* DISPLAY_H */
