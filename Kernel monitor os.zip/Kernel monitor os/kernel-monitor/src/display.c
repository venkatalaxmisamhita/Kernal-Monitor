#include "display.h"
#include "io.h"
#include "alerts.h"

void display_clear(void) {
    printf("\033[2J\033[H");
    fflush(stdout);
}

void display_separator(void) {
    printf("--------------------------------------------------\n");
}

void display_section(const char *title) {
    printf("\n%s%s%s\n", COLOR_BOLD, title, COLOR_RESET);
    display_separator();
}

static void display_header(process_list_t *list) {
    printf("%s", COLOR_CYAN);
    printf("==================================================\n");
    printf("                 KERNEL MONITOR                    \n");
    printf("==================================================\n");
    printf("%s", COLOR_RESET);
    printf("\n");
    printf("Monitoring      : ALL PROCESSES\n");
    printf("Processes       : %d\n", list->count);
    printf("Refresh Rate    : 1 sec\n");
    printf("Press Ctrl+C to stop.\n");
}

static void display_process_table(process_list_t *list) {
    display_section("PROCESS MONITORING");

    printf("%s%-8s %-16s %-10s %-10s %-10s %-10s%s\n",
           COLOR_BOLD,
           "PID", "PROCESS", "CPU", "MEMORY", "MEM(MB)", "STATE",
           COLOR_RESET);
    display_separator();

    int display_count = list->count;
    if (display_count > MAX_DISPLAY_PROCS) display_count = MAX_DISPLAY_PROCS;

    for (int i = 0; i < display_count; i++) {
        process_info_t *proc = &list->procs[i];
        if (!proc->active) continue;

        /* Color based on CPU usage */
        const char *color = COLOR_RESET;
        if (proc->cpu_percent > 80.0) color = COLOR_RED;
        else if (proc->cpu_percent > 50.0) color = COLOR_YELLOW;
        else if (proc->cpu_percent > 0.1) color = COLOR_GREEN;

        printf("%s%-8d %-16.16s %6.2f%%    %6.2f%%    %7.1f    %-10s%s\n",
               color,
               proc->pid,
               proc->name,
               proc->cpu_percent,
               proc->mem_percent,
               proc->mem_mb,
               proc->state_str,
               COLOR_RESET);
    }

    if (list->count > MAX_DISPLAY_PROCS) {
        printf("%s... and %d more processes%s\n",
               COLOR_DIM, list->count - MAX_DISPLAY_PROCS, COLOR_RESET);
    }
}

static void display_selected_process(process_info_t *proc) {
    if (!proc) return;

    char time_buf[32];
    format_time(proc->running_seconds, time_buf, sizeof(time_buf));

    display_section("SELECTED PROCESS");
    printf("PID             : %d\n", proc->pid);
    printf("Process         : %s\n", proc->name);
    printf("Parent PID      : %d\n", proc->ppid);
    printf("State           : %s\n", proc->state_str);
    printf("CPU Usage       : %.2f%%\n", proc->cpu_percent);
    printf("Memory Usage    : %.2f%%\n", proc->mem_percent);
    printf("Memory          : %.0f MB\n", proc->mem_mb);
    printf("Threads         : %d\n", proc->threads);
    printf("CPU Core        : %d\n", proc->cpu_core);
    printf("Running Time    : %s\n", time_buf);
}

static void display_cpu_analysis(process_info_t *proc) {
    if (!proc) return;

    display_section("CPU ANALYSIS");
    printf("Current CPU     : %.2f%%\n", proc->cpu_percent);
    printf("Average CPU     : %.2f%%\n", proc->cpu_avg);
    printf("Peak CPU        : %.2f%%\n", proc->cpu_peak);
    printf("Minimum CPU     : %.2f%%\n", proc->cpu_min > 900.0 ? 0.0 : proc->cpu_min);
    printf("CPU Trend       : %s\n", cpu_trend_string(proc));
    printf("CPU Status      : %s%s%s\n",
           proc->cpu_percent > 80.0 ? COLOR_RED :
           proc->cpu_percent > 50.0 ? COLOR_YELLOW : COLOR_GREEN,
           cpu_status_string(proc->cpu_percent),
           COLOR_RESET);
}

static void display_memory_analysis(process_info_t *proc) {
    if (!proc) return;

    display_section("MEMORY ANALYSIS");
    printf("Current Memory  : %.2f%%\n", proc->mem_percent);
    printf("Average Memory  : %.2f%%\n", proc->mem_avg);
    printf("Peak Memory     : %.2f%%\n", proc->mem_peak);
    printf("Minimum Memory  : %.2f%%\n", proc->mem_min > 900.0 ? 0.0 : proc->mem_min);
    printf("Memory Trend    : %s\n", memory_trend_string(proc));
    printf("Memory Status   : %s%s%s\n",
           proc->mem_percent > 80.0 ? COLOR_RED :
           proc->mem_percent > 50.0 ? COLOR_YELLOW : COLOR_GREEN,
           memory_status_string(proc->mem_percent),
           COLOR_RESET);
}

static void display_io_analysis(process_info_t *proc) {
    if (!proc) return;

    display_section("I/O ANALYSIS");
    printf("Read            : %.2f MB/s\n", proc->read_rate);
    printf("Write           : %.2f MB/s\n", proc->write_rate);
    printf("I/O Status      : %s%s%s\n",
           (proc->read_rate + proc->write_rate) > 100.0 ? COLOR_RED : COLOR_GREEN,
           io_status_string(proc->read_rate, proc->write_rate),
           COLOR_RESET);
}

static void display_syscall_activity(syscall_monitor_t *mon) {
    display_section("SYSTEM CALL ACTIVITY");

    if (!mon->available) {
        printf("%sSystem call monitoring unavailable (strace not found)%s\n",
               COLOR_YELLOW, COLOR_RESET);
        return;
    }

    if (mon->target_pid <= 0) {
        printf("%sNo process selected for syscall monitoring%s\n",
               COLOR_DIM, COLOR_RESET);
        return;
    }

    if (mon->entry_count == 0) {
        printf("%sCapturing system calls...%s\n", COLOR_DIM, COLOR_RESET);
        return;
    }

    /* Show syscall counts */
    int show = mon->entry_count;
    if (show > 10) show = 10;

    printf("%-20s : %s\n", "SYSCALL", "COUNT");
    display_separator();
    for (int i = 0; i < show; i++) {
        printf("%-20s : %d\n",
               mon->entries[i].name,
               mon->entries[i].count);
    }

    /* Show recent syscalls */
    if (mon->recent_count > 0) {
        printf("\nRecent System Calls:\n");
        int start = mon->recent_count > 5 ? mon->recent_count - 5 : 0;
        for (int i = start; i < mon->recent_count; i++) {
            printf("  %s  %s\n",
                   mon->recent[i].timestamp,
                   mon->recent[i].name);
        }
    }
}

static void display_system_analysis(process_list_t *list,
                                     system_cpu_t *sys_cpu,
                                     system_memory_t *sys_mem) {
    display_section("SYSTEM ANALYSIS");

    printf("Total Processes : %d\n", list->count);
    printf("Running         : %d\n", list->total_running);
    printf("Sleeping        : %d\n", list->total_sleeping);
    printf("Stopped         : %d\n", list->total_stopped);
    printf("Zombie          : %d\n", list->total_zombie);
    printf("\n");
    printf("Overall CPU     : %.2f%%\n", sys_cpu->overall_cpu_percent);
    printf("Overall Memory  : %.2f%%\n", sys_mem->used_percent);

    /* Determine system health */
    const char *health;
    const char *health_color;
    if (sys_cpu->overall_cpu_percent > 90.0 || sys_mem->used_percent > 90.0) {
        health = "CRITICAL";
        health_color = COLOR_RED;
    } else if (sys_cpu->overall_cpu_percent > 70.0 || sys_mem->used_percent > 70.0) {
        health = "WARNING";
        health_color = COLOR_YELLOW;
    } else {
        health = "NORMAL";
        health_color = COLOR_GREEN;
    }
    printf("Overall Health  : %s%s%s\n", health_color, health, COLOR_RESET);
}

static void display_alerts(process_list_t *list) {
    display_section("ALERTS");

    int has_alerts = 0;

    /* Show alerts for top processes */
    int show = list->count;
    if (show > MAX_DISPLAY_PROCS) show = MAX_DISPLAY_PROCS;

    for (int i = 0; i < show; i++) {
        process_info_t *proc = &list->procs[i];
        if (!proc->active) continue;

        /* Only show processes that have some CPU or memory activity */
        if (proc->cpu_percent < 0.01 && proc->mem_percent < 0.01) continue;

        if (proc->cpu_alert || proc->mem_alert) {
            has_alerts = 1;
            if (proc->cpu_alert) {
                printf("%sPID %-6d %-16.16s CPU       : HIGH%s\n",
                       COLOR_RED, proc->pid, proc->name, COLOR_RESET);
            }
            if (proc->mem_alert) {
                printf("%sPID %-6d %-16.16s MEMORY    : HIGH%s\n",
                       COLOR_RED, proc->pid, proc->name, COLOR_RESET);
            }
        } else if (proc->cpu_percent > 0.1 || proc->mem_percent > 0.1) {
            printf("PID %-6d %-16.16s CPU: %s%-7s%s  MEM: %s%-7s%s\n",
                   proc->pid, proc->name,
                   COLOR_GREEN, alert_cpu_string(proc), COLOR_RESET,
                   COLOR_GREEN, alert_mem_string(proc), COLOR_RESET);
        }
    }

    if (!has_alerts) {
        printf("%sNo active alerts%s\n", COLOR_GREEN, COLOR_RESET);
    }
}

void display_render(
    process_list_t *list,
    system_cpu_t *sys_cpu,
    system_memory_t *sys_mem,
    process_info_t *selected,
    syscall_monitor_t *syscall_mon)
{
    display_clear();

    display_header(list);
    display_process_table(list);
    display_selected_process(selected);
    display_cpu_analysis(selected);
    display_memory_analysis(selected);
    display_io_analysis(selected);
    display_syscall_activity(syscall_mon);
    display_system_analysis(list, sys_cpu, sys_mem);
    display_alerts(list);

    printf("\n%s==================================================\n", COLOR_DIM);

    char time_buf[16];
    get_time_string(time_buf, sizeof(time_buf));
    printf("Last updated: %s%s\n", time_buf, COLOR_RESET);
}
