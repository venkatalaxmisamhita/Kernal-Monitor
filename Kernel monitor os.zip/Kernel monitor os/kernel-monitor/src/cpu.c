#include "cpu.h"

void cpu_init(system_cpu_t *sys) {
    memset(sys, 0, sizeof(*sys));
    sys->num_cpus = get_num_cpus();
    /* Take initial reading */
    cpu_read_system(sys);
}

void cpu_read_system(system_cpu_t *sys) {
    char buf[MAX_LINE];
    if (read_file_line("/proc/stat", buf, sizeof(buf)) != 0)
        return;

    /* First line: cpu  user nice system idle iowait irq softirq steal guest guest_nice */
    unsigned long long user, nice, system_t, idle, iowait, irq, softirq, steal;
    int n = sscanf(buf, "cpu  %llu %llu %llu %llu %llu %llu %llu %llu",
                   &user, &nice, &system_t, &idle, &iowait, &irq, &softirq, &steal);

    if (n < 4) return;
    if (n < 8) { iowait = 0; irq = 0; softirq = 0; steal = 0; }

    /* Save previous values */
    sys->total_prev = sys->total_cur;
    sys->idle_prev = sys->idle_cur;

    sys->idle_cur = idle + iowait;
    sys->total_cur = user + nice + system_t + idle + iowait + irq + softirq + steal;
}

void cpu_calculate_system(system_cpu_t *sys) {
    unsigned long long total_delta = sys->total_cur - sys->total_prev;
    unsigned long long idle_delta = sys->idle_cur - sys->idle_prev;

    if (total_delta == 0) {
        sys->overall_cpu_percent = 0.0;
        return;
    }

    sys->overall_cpu_percent = (double)(total_delta - idle_delta) / (double)total_delta * 100.0;
}

void cpu_update_all(process_list_t *list, system_cpu_t *sys) {
    unsigned long long total_delta = sys->total_cur - sys->total_prev;

    for (int i = 0; i < list->count; i++) {
        process_info_t *proc = &list->procs[i];

        if (!proc->active) continue;

        /* Skip first sample (no previous data) */
        if (proc->prev_utime == 0 && proc->prev_stime == 0) {
            proc->cpu_percent = 0.0;
            continue;
        }

        unsigned long proc_delta = (proc->utime - proc->prev_utime) +
                                   (proc->stime - proc->prev_stime);

        if (total_delta == 0) {
            proc->cpu_percent = 0.0;
        } else {
            proc->cpu_percent = (double)proc_delta / (double)total_delta * 100.0 * sys->num_cpus;
        }

        /* Clamp to reasonable values */
        if (proc->cpu_percent > 100.0 * sys->num_cpus)
            proc->cpu_percent = 100.0 * sys->num_cpus;
        if (proc->cpu_percent < 0.0)
            proc->cpu_percent = 0.0;
    }
}

void cpu_update_analysis(process_info_t *proc) {
    if (!proc) return;

    proc->cpu_sample_count++;
    proc->cpu_sum += proc->cpu_percent;
    proc->cpu_avg = proc->cpu_sum / proc->cpu_sample_count;

    if (proc->cpu_percent > proc->cpu_peak)
        proc->cpu_peak = proc->cpu_percent;
    if (proc->cpu_percent < proc->cpu_min)
        proc->cpu_min = proc->cpu_percent;
}

const char *cpu_trend_string(process_info_t *proc) {
    if (!proc || proc->cpu_sample_count < 2) return "Stable";

    double diff = proc->cpu_percent - proc->cpu_avg;
    if (diff > 5.0) return "Increasing";
    if (diff < -5.0) return "Decreasing";
    return "Stable";
}

const char *cpu_status_string(double cpu_percent) {
    if (cpu_percent > 80.0) return "HIGH";
    if (cpu_percent > 50.0) return "MODERATE";
    return "NORMAL";
}
