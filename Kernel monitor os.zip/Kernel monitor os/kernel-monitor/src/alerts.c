#include "alerts.h"

void alerts_update(process_list_t *list) {
    for (int i = 0; i < list->count; i++) {
        process_info_t *proc = &list->procs[i];
        if (!proc->active) continue;

        /* CPU alert tracking */
        if (proc->cpu_percent > ALERT_THRESHOLD_CPU) {
            proc->cpu_high_count++;
        } else {
            proc->cpu_high_count = 0;
        }
        proc->cpu_alert = (proc->cpu_high_count >= ALERT_CONSECUTIVE) ? 1 : 0;

        /* Memory alert tracking */
        if (proc->mem_percent > ALERT_THRESHOLD_MEM) {
            proc->mem_high_count++;
        } else {
            proc->mem_high_count = 0;
        }
        proc->mem_alert = (proc->mem_high_count >= ALERT_CONSECUTIVE) ? 1 : 0;
    }
}

const char *alert_cpu_string(process_info_t *proc) {
    if (proc->cpu_alert) return "HIGH";
    return "NORMAL";
}

const char *alert_mem_string(process_info_t *proc) {
    if (proc->mem_alert) return "HIGH";
    return "NORMAL";
}
