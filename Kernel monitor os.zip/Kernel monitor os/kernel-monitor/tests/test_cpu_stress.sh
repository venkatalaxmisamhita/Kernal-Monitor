#!/bin/bash
#
# test_cpu_stress.sh — Launch CPU-intensive processes to test the Kernel Monitor
#
# Usage: ./tests/test_cpu_stress.sh
#
# This script creates temporary CPU and memory load to verify that
# the Kernel Monitor correctly detects and reports:
#   1. New processes appearing
#   2. High CPU usage
#   3. High memory usage (if available)
#   4. Processes terminating
#

echo "============================================"
echo "  Kernel Monitor - Test Script"
echo "============================================"
echo ""

# Check if the monitor binary exists
if [ ! -f "./kernel_monitor" ]; then
    echo "ERROR: kernel_monitor binary not found."
    echo "Please run 'make' first."
    exit 1
fi

cleanup() {
    echo ""
    echo "Cleaning up test processes..."
    kill $PID1 $PID2 $PID3 2>/dev/null
    wait $PID1 $PID2 $PID3 2>/dev/null
    echo "Done."
}

trap cleanup EXIT

echo "[1] Starting CPU-intensive process (dd)..."
dd if=/dev/urandom of=/dev/null bs=1M count=10000 2>/dev/null &
PID1=$!
echo "    PID: $PID1"

echo "[2] Starting CPU-intensive process (yes > /dev/null)..."
yes > /dev/null &
PID2=$!
echo "    PID: $PID2"

echo "[3] Starting I/O-intensive process (dd to /tmp)..."
dd if=/dev/zero of=/tmp/kernel_monitor_test_io bs=1M count=500 2>/dev/null &
PID3=$!
echo "    PID: $PID3"

echo ""
echo "Test processes started."
echo "PIDs to look for in the monitor: $PID1, $PID2, $PID3"
echo ""
echo "Now run the Kernel Monitor in another terminal:"
echo "  ./kernel_monitor"
echo ""
echo "Verify that:"
echo "  - The PIDs above appear in the process table"
echo "  - CPU usage is reported as > 0% for PID $PID1 and $PID2"
echo "  - I/O activity is reported for PID $PID3"
echo "  - When this script exits, the processes disappear from the monitor"
echo ""
echo "Press Enter to stop the test processes and exit..."
read -r

echo "Test complete."
